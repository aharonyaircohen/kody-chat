/**
 * @fileType library
 * @domain previews
 * @pattern fly-machines-client
 * @ai-summary Thin Fly Machines REST + GraphQL client tailored to
 *   long-lived, auto-suspending preview apps (per-PR apps with their own
 *   `<app>.fly.dev` hostnames). Kept separate from `runners/fly.ts` because
 *   runners spawn one-shot machines that exit, while previews must run
 *   for the lifetime of a PR and tolerate Fly registry races via retry.
 *   Trap: Machines API field names are `autostop`/`autostart` — the
 *   fly.toml names (`auto_stop_machines`/`auto_start_machines`) are
 *   silently dropped, leaving a machine running 24/7 and unable to
 *   auto-wake. Use the API names.
 *
 * Fly Machines REST + GraphQL client for PR preview hosting.
 *
 * Separate from the runners' `fly.ts` because:
 *   - runners spawn one-shot machines that exit; previews are long-lived
 *     HTTP services that auto-suspend.
 *   - previews need app creation + IP allocation per PR (each preview is
 *     its own app, so it gets its own <app>.fly.dev hostname).
 *   - runners share one `kody-runner` app; previews can't.
 */

const FLY_MACHINES_BASE = "https://api.machines.dev/v1";
const FLY_GRAPHQL = "https://api.fly.io/graphql";
const REQUEST_TIMEOUT_MS = 30_000;
const FLY_SUSPEND_MEMORY_LIMIT_MB = 2048;

export interface FlyPreviewConfig {
  token: string;
  orgSlug: string;
  defaultRegion: string;
}

export interface CreatePreviewMachineInput {
  appName: string;
  region: string;
  image: string;
  env?: Record<string, string>;
  internalPort?: number;
  memoryMb?: number;
  cpus?: number;
  cpuKind?: "shared" | "performance";
  /**
   * Files written into the machine's filesystem at boot via Fly's
   * `config.files` (base64 `raw_value`). Lets us serve uploaded static
   * content from a stock image with no Docker build — see `static-preview.ts`.
   */
  files?: Array<{ guestPath: string; contentBase64: string }>;
  /**
   * Whether to attach a periodic HTTP health check to the machine. Default
   * is `false` — without a check, Fly's `autostop: "suspend"` can fire on
   * idle (a check would count traffic and keep the machine "active"
   * forever, defeating the suspend). Opt in only for repos that want
   * health-gated previews and accept the machine stays awake.
   * Mirrors the builder's `fly.previews.healthCheck` config flag.
   */
  healthCheck?: boolean;
}

export interface MachineInfo {
  id: string;
  state: string;
  region: string;
  /** ISO timestamp Fly reports as the machine's creation time. Used by the
   * TTL sweep to decide whether a preview is past its expiry. */
  createdAt?: string;
  /** Machine name (Fly-assigned or set at create). */
  name?: string;
  /** Guest sizing — populated for the machines-inventory view. */
  guest?: { cpuKind?: string; cpus?: number; memoryMb?: number };
  /** Full Fly machine config, present on direct machine reads/list calls. */
  config?: MachineConfig;
}

export type MachineServiceConfig = Record<string, unknown> & {
  autostop?: boolean | "suspend";
  autostart?: boolean;
  min_machines_running?: number;
};

export interface MachineConfig {
  image?: string;
  checks?: unknown;
  guest?: { cpu_kind?: string; cpus?: number; memory_mb?: number };
  services?: MachineServiceConfig[];
  [key: string]: unknown;
}

function autostopForMemory(memoryMb: number | undefined): "suspend" | true {
  const effectiveMemoryMb = memoryMb ?? 512;
  return effectiveMemoryMb <= FLY_SUSPEND_MEMORY_LIMIT_MB ? "suspend" : true;
}

/**
 * Transient errors we see from Vercel→Fly: TLS handshake races,
 * ECONNRESET mid-request, and undici socket aborts. The Fly Machines API
 * is idempotent enough on GET + safe for short retries on POST/DELETE
 * (consumer-side dedup handles the rest), so backed-off retry keeps the
 * webhook flow from dying on a single network blip.
 */
function isTransientFetchError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return /socket|ECONNRESET|ENOTFOUND|ETIMEDOUT|TLS|EAI_AGAIN|fetch failed/i.test(
    msg,
  );
}

async function flyFetch(
  url: string,
  init: RequestInit,
  token: string,
): Promise<Response> {
  const headers = {
    Authorization: `Bearer ${token}`,
    "Content-Type": "application/json",
    ...(init.headers ?? {}),
  };
  let lastErr: unknown;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      return await fetch(url, {
        ...init,
        headers,
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
    } catch (err) {
      lastErr = err;
      if (!isTransientFetchError(err)) throw err;
      await new Promise((r) => setTimeout(r, 500 * (attempt + 1)));
    }
  }
  throw lastErr ?? new Error("flyFetch exhausted retries");
}

async function assertOk(res: Response, context: string): Promise<void> {
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(
      `${context} failed: ${res.status} ${res.statusText} — ${text.slice(0, 400)}`,
    );
  }
}

export async function appExists(
  appName: string,
  cfg: FlyPreviewConfig,
): Promise<boolean> {
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}`,
    { method: "GET" },
    cfg.token,
  );
  if (res.status === 404) return false;
  await assertOk(res, "appExists");
  return true;
}

export async function createApp(
  appName: string,
  cfg: FlyPreviewConfig,
): Promise<void> {
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps`,
    {
      method: "POST",
      body: JSON.stringify({
        app_name: appName,
        org_slug: cfg.orgSlug,
      }),
    },
    cfg.token,
  );
  if (res.status === 422) return; // name taken — idempotent
  await assertOk(res, "createApp");
}

/**
 * Allocate shared IPv4 + IPv6 via GraphQL. Required for the
 * auto-provisioned `<app>.fly.dev` hostname to answer HTTPS.
 * Shared v4 = free; dedicated v4 would be $2/mo and is unnecessary here.
 */
export async function allocateSharedIps(
  appName: string,
  cfg: FlyPreviewConfig,
): Promise<void> {
  const mutation = `
    mutation AllocateIps($appId: ID!) {
      v4: allocateIpAddress(input: { appId: $appId, type: shared_v4 }) {
        ipAddress { address }
      }
      v6: allocateIpAddress(input: { appId: $appId, type: v6 }) {
        ipAddress { address }
      }
    }
  `;
  const res = await flyFetch(
    FLY_GRAPHQL,
    {
      method: "POST",
      body: JSON.stringify({ query: mutation, variables: { appId: appName } }),
    },
    cfg.token,
  );
  await assertOk(res, "allocateSharedIps");
  const data = (await res.json()) as { errors?: Array<{ message: string }> };
  if (data.errors && data.errors.length > 0) {
    const msgs = data.errors.map((e) => e.message).join("; ");
    if (!/already|exists/i.test(msgs)) {
      throw new Error(`allocateSharedIps failed: ${msgs}`);
    }
  }
}

export async function createMachine(
  input: CreatePreviewMachineInput,
  cfg: FlyPreviewConfig,
): Promise<MachineInfo> {
  const internalPort = input.internalPort ?? 8080;
  const body = {
    region: input.region,
    config: {
      image: input.image,
      env: input.env ?? {},
      auto_destroy: false,
      restart: { policy: "always" },
      ...(input.files && input.files.length > 0
        ? {
            files: input.files.map((f) => ({
              guest_path: f.guestPath,
              raw_value: f.contentBase64,
            })),
          }
        : {}),
      guest: {
        cpu_kind: input.cpuKind ?? "shared",
        cpus: input.cpus ?? 1,
        memory_mb: input.memoryMb ?? 512,
      },
      services: [
        {
          ports: [
            { port: 443, handlers: ["tls", "http"], force_https: false },
            { port: 80, handlers: ["http"] },
          ],
          protocol: "tcp",
          internal_port: internalPort,
          // Machines API field names are `autostop`/`autostart` — the
          // fly.toml names (`auto_stop_machines`/`auto_start_machines`) are
          // silently dropped, leaving the machine running 24/7 + unable to
          // auto-wake. (Same bug bit the per-PR builder path.)
          // Fly suspend is limited/recommended at <= 2 GB. Larger previews
          // still need to sleep, so use stop mode instead of staying started.
          autostop: autostopForMemory(input.memoryMb),
          autostart: true,
          min_machines_running: 0,
        },
      ],
      // By default NO machine-level `checks`: a periodic HTTP check (we had
      // GET / every 15s) issues a request to the machine forever, so Fly
      // never sees it as idle and `autostop: "suspend"` can never fire. Opt
      // back in only when the caller explicitly asks for it.
      ...(input.healthCheck
        ? {
            checks: {
              httpget: {
                type: "http",
                port: internalPort,
                method: "GET",
                path: "/",
                interval: "15s",
                timeout: "10s",
                grace_period: "30s",
              },
            },
          }
        : {}),
    },
  };

  // Fly's registry is eventually consistent: a freshly-pushed manifest
  // can return MANIFEST_UNKNOWN for a few seconds. Retry on that
  // specific class of error.
  let lastErr: Error | null = null;
  for (let attempt = 0; attempt < 6; attempt++) {
    const res = await flyFetch(
      `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(input.appName)}/machines`,
      { method: "POST", body: JSON.stringify(body) },
      cfg.token,
    );
    if (res.ok) {
      const data = (await res.json()) as {
        id: string;
        state: string;
        region: string;
      };
      return { id: data.id, state: data.state, region: data.region };
    }
    const text = await res.text().catch(() => "");
    const isManifestRace = /MANIFEST_UNKNOWN|manifest unknown/i.test(text);
    lastErr = new Error(
      `createMachine failed: ${res.status} ${res.statusText} — ${text.slice(0, 400)}`,
    );
    if (!isManifestRace) break;
    await new Promise((r) => setTimeout(r, 2000 * (attempt + 1)));
  }
  throw lastErr ?? new Error("createMachine failed (unknown)");
}

export async function waitForMachineStarted(
  appName: string,
  machineId: string,
  cfg: FlyPreviewConfig,
  timeoutMs = 60_000,
): Promise<void> {
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}/machines/${encodeURIComponent(machineId)}/wait?state=started&timeout=${Math.floor(timeoutMs / 1000)}`,
    { method: "GET" },
    cfg.token,
  );
  await assertOk(res, "waitForMachineStarted");
}

export async function listMachines(
  appName: string,
  cfg: FlyPreviewConfig,
): Promise<MachineInfo[]> {
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}/machines`,
    { method: "GET" },
    cfg.token,
  );
  if (res.status === 404) return [];
  await assertOk(res, "listMachines");
  const data = (await res.json()) as Array<{
    id: string;
    name?: string;
    state: string;
    region: string;
    created_at?: string;
    config?: MachineConfig;
  }>;
  return data.map((m) => ({
    id: m.id,
    name: m.name,
    state: m.state,
    region: m.region,
    createdAt: m.created_at,
    guest: m.config?.guest
      ? {
          cpuKind: m.config.guest.cpu_kind,
          cpus: m.config.guest.cpus,
          memoryMb: m.config.guest.memory_mb,
        }
      : undefined,
    config: m.config,
  }));
}

async function getMachine(
  appName: string,
  machineId: string,
  cfg: FlyPreviewConfig,
): Promise<MachineInfo | null> {
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}/machines/${encodeURIComponent(machineId)}`,
    { method: "GET" },
    cfg.token,
  );
  if (res.status === 404) return null;
  await assertOk(res, "getMachine");
  const data = (await res.json()) as {
    id: string;
    name?: string;
    state: string;
    region: string;
    created_at?: string;
    config?: MachineConfig;
  };
  return {
    id: data.id,
    name: data.name,
    state: data.state,
    region: data.region,
    createdAt: data.created_at,
    guest: data.config?.guest
      ? {
          cpuKind: data.config.guest.cpu_kind,
          cpus: data.config.guest.cpus,
          memoryMb: data.config.guest.memory_mb,
        }
      : undefined,
    config: data.config,
  };
}

async function updateMachineConfig(
  appName: string,
  machineId: string,
  config: MachineConfig,
  cfg: FlyPreviewConfig,
): Promise<void> {
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}/machines/${encodeURIComponent(machineId)}`,
    { method: "POST", body: JSON.stringify({ config }) },
    cfg.token,
  );
  if (res.status === 404) return;
  await assertOk(res, "updateMachineConfig");
}

export interface AlignPreviewMachineSleepOptions {
  idleSuspend: boolean;
  healthCheck: boolean;
  memoryMb?: number;
}

export type AlignPreviewMachineSleepResult =
  | { changed: true; skipped: false }
  | { changed: false; skipped: false }
  | { changed: false; skipped: true; reason: string };

export type SleepPreviewMachineResult =
  | { slept: true; mode: "suspend" | "stop" }
  | { slept: false; reason: string };

export function alignPreviewMachineSleepConfig(
  config: MachineConfig | undefined,
  options: AlignPreviewMachineSleepOptions,
): AlignPreviewMachineSleepResult & { config?: MachineConfig } {
  if (!config) {
    return { changed: false, skipped: true, reason: "missing_config" };
  }
  if (!Array.isArray(config.services) || config.services.length === 0) {
    return { changed: false, skipped: true, reason: "missing_services" };
  }

  const memoryMb =
    options.memoryMb ??
    (typeof config.guest?.memory_mb === "number"
      ? config.guest.memory_mb
      : undefined);
  const targetAutostop = options.idleSuspend
    ? autostopForMemory(memoryMb)
    : false;

  let changed = false;
  const services = config.services.map((service) => {
    const next = { ...service };
    if (next.autostop !== targetAutostop) {
      next.autostop = targetAutostop;
      changed = true;
    }
    if (next.autostart !== true) {
      next.autostart = true;
      changed = true;
    }
    if (next.min_machines_running !== 0) {
      next.min_machines_running = 0;
      changed = true;
    }
    return next;
  });

  const nextConfig: MachineConfig = { ...config, services };
  if (!options.healthCheck && "checks" in nextConfig) {
    delete nextConfig.checks;
    changed = true;
  }

  return { config: nextConfig, changed, skipped: false };
}

export async function alignPreviewMachineSleep(
  appName: string,
  machineId: string,
  cfg: FlyPreviewConfig,
  options: AlignPreviewMachineSleepOptions,
): Promise<AlignPreviewMachineSleepResult> {
  const machine = await getMachine(appName, machineId, cfg);
  const aligned = alignPreviewMachineSleepConfig(machine?.config, options);
  if (aligned.skipped) return aligned;
  if (!aligned.changed) return { changed: false, skipped: false };
  await updateMachineConfig(appName, machineId, aligned.config!, cfg);
  return { changed: true, skipped: false };
}

/**
 * List every Fly app in the org whose name starts with `prefix`. Used by the
 * preview TTL sweep to enumerate a repo's preview apps (`kp-<owner>-<repo>-`).
 * Returns app names only — the sweep then inspects each app's machines.
 */
export async function listAppsByPrefix(
  prefix: string,
  cfg: FlyPreviewConfig,
): Promise<string[]> {
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps?org_slug=${encodeURIComponent(cfg.orgSlug)}`,
    { method: "GET" },
    cfg.token,
  );
  await assertOk(res, "listAppsByPrefix");
  const data = (await res.json()) as { apps?: Array<{ name?: string }> };
  return (data.apps ?? [])
    .map((a) => a.name ?? "")
    .filter((n) => n.startsWith(prefix));
}

export async function destroyMachine(
  appName: string,
  machineId: string,
  cfg: FlyPreviewConfig,
): Promise<void> {
  // Stop first (Fly requires `force=true` to destroy a started machine in
  // one call; using stop+destroy is more predictable).
  await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}/machines/${encodeURIComponent(machineId)}/stop`,
    { method: "POST" },
    cfg.token,
  ).catch(() => undefined);
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}/machines/${encodeURIComponent(machineId)}?force=true`,
    { method: "DELETE" },
    cfg.token,
  );
  if (res.status === 404) return;
  await assertOk(res, "destroyMachine");
}

/** Stop a machine: cold sleep, wakes on request when service autostart=true. */
export async function stopMachine(
  appName: string,
  machineId: string,
  cfg: FlyPreviewConfig,
): Promise<void> {
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}/machines/${encodeURIComponent(machineId)}/stop`,
    { method: "POST" },
    cfg.token,
  );
  if (res.status === 404) return;
  await assertOk(res, "stopMachine");
}

/** Suspend a machine: snapshot RAM to disk, ~$0 while idle, wakes on request
 * (or via {@link startMachine}). No-op (404 tolerated) if it's already gone. */
export async function suspendMachine(
  appName: string,
  machineId: string,
  cfg: FlyPreviewConfig,
): Promise<void> {
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}/machines/${encodeURIComponent(machineId)}/suspend`,
    { method: "POST" },
    cfg.token,
  );
  if (res.status === 404) return;
  await assertOk(res, "suspendMachine");
}

/** Start (wake) a suspended/stopped machine. */
export async function startMachine(
  appName: string,
  machineId: string,
  cfg: FlyPreviewConfig,
): Promise<void> {
  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}/machines/${encodeURIComponent(machineId)}/start`,
    { method: "POST" },
    cfg.token,
  );
  if (res.status === 404) return;
  await assertOk(res, "startMachine");
}

/** Put a preview machine to sleep now. Uses suspend when Fly supports it and
 * cold-stop for larger machines; both wake on request once autostart is set. */
export async function sleepPreviewMachine(
  appName: string,
  machineId: string,
  cfg: FlyPreviewConfig,
  input: { state: string; memoryMb?: number },
): Promise<SleepPreviewMachineResult> {
  if (input.state !== "started") {
    return { slept: false, reason: "not_started" };
  }
  const effectiveMemoryMb = input.memoryMb ?? 512;
  if (effectiveMemoryMb <= FLY_SUSPEND_MEMORY_LIMIT_MB) {
    await suspendMachine(appName, machineId, cfg);
    return { slept: true, mode: "suspend" };
  }
  await stopMachine(appName, machineId, cfg);
  return { slept: true, mode: "stop" };
}

export async function destroyApp(
  appName: string,
  cfg: FlyPreviewConfig,
): Promise<void> {
  const machines = await listMachines(appName, cfg);
  for (const machine of machines) {
    await destroyMachine(appName, machine.id, cfg);
  }

  const res = await flyFetch(
    `${FLY_MACHINES_BASE}/apps/${encodeURIComponent(appName)}`,
    { method: "DELETE" },
    cfg.token,
  );
  if (res.status === 404) return;
  await assertOk(res, "destroyApp");
}

export function flyHostname(appName: string): string {
  return `https://${appName}.fly.dev`;
}
