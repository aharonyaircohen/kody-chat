/**
 * @fileType component
 * @domain kody-chat
 * @pattern client-provider
 * @ai-summary Client-side providers for kody-chat (QueryClientProvider + ThemeProvider + AuthProvider)
 */
"use client";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import React from "react";
import { ThemeProvider } from "@dashboard/providers/Theme";
import { AuthProvider } from "@dashboard/lib/auth-context";
import { ServiceWorkerRegister } from "@dashboard/lib/push/ServiceWorkerRegister";

function makeQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 60 * 1000, // 1 minute
        refetchOnWindowFocus: false,
      },
    },
  });
}

let browserQueryClient: QueryClient | undefined = undefined;

function getQueryClient() {
  if (typeof window === "undefined") {
    return makeQueryClient();
  } else {
    if (!browserQueryClient) browserQueryClient = makeQueryClient();
    return browserQueryClient;
  }
}

export function KodyProviders({ children }: { children: React.ReactNode }) {
  const queryClient = getQueryClient();

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <ServiceWorkerRegister />
          {children}
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
